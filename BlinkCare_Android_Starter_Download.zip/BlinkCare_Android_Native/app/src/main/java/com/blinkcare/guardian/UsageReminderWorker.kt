package com.blinkcare.guardian

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters

class UsageReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("blinkcare_usage", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val start = now - 24L * 60L * 60L * 1000L
        val usage = applicationContext.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val stats = try { usage.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, now) } catch (_: SecurityException) { emptyList() }
        val totalMs = stats.sumOf { it.totalTimeInForeground }
        val lastAlert = prefs.getLong("last_alert", 0L)
        val totalMinutes = totalMs / 60000L
        val lastAlertMinutes = prefs.getLong("last_alert_minutes", 0L)
        // Coarse device-wide usage estimate; UsageStats availability and vendor behavior vary.
        if (totalMinutes >= 20 && (now - lastAlert > 20L * 60L * 1000L) && totalMinutes >= lastAlertMinutes + 20) {
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel("blinkcare_reminders", "BlinkCare reminders", NotificationManager.IMPORTANCE_HIGH)
            manager.createNotificationChannel(channel)
            val intent = PendingIntent.getActivity(applicationContext, 0, Intent(applicationContext, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val n = NotificationCompat.Builder(applicationContext, "blinkcare_reminders")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("BlinkCare · พักสายตาสักครู่")
                .setContentText("คุณใช้หน้าจอมาเป็นเวลานาน ลองมองไกลและพักสายตาสักครู่")
                .setContentIntent(intent).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
            manager.notify(2001, n)
            prefs.edit().putLong("last_alert", now).putLong("last_alert_minutes", totalMinutes).apply()
        }
        return Result.success()
    }
}
