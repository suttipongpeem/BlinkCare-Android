package com.blinkcare.guardian

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var lightSensor: Sensor? = null
    private var webView: WebView? = null
    private var latestLux: Float? = null
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        requestRuntimePermissions()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 10)
        }
        status = TextView(this).apply {
            textSize = 13f
            text = if (lightSensor == null) "Ambient Light Sensor: อุปกรณ์ไม่พบเซนเซอร์แสง" else "Ambient Light Sensor: พร้อมอ่านค่า"
            setPadding(4, 4, 4, 10)
        }
        val usageButton = Button(this).apply {
            text = "เปิดสิทธิ์ติดตามเวลาการใช้แอป"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        }
        val reminderButton = Button(this).apply {
            text = "เปิดระบบเตือนพักสายตา"
            setOnClickListener {
                scheduleUsageCheck()
                notifyUser("BlinkCare เปิดระบบเตือนแล้ว", "ระบบจะตรวจสอบเวลาการใช้แอปเป็นระยะ")
            }
        }
        layout.addView(status)
        layout.addView(usageButton)
        layout.addView(reminderButton)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: android.webkit.PermissionRequest) {
                    // Only grant camera capture requested by the app's own bundled page.
                    if (request.resources.contains(android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                        request.grant(arrayOf(android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                    } else request.deny()
                }
            }
            webViewClient = WebViewClient()
            addJavascriptInterface(NativeBridge(this@MainActivity), "BlinkCareNative")
            loadUrl("file:///android_asset/index.html")
        }
        layout.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        lightSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_LIGHT) {
            latestLux = event.values.firstOrNull()
            status.text = "Ambient Light Sensor: ${latestLux?.let { "%.0f lux".format(it) } ?: "—"}"
            webView?.evaluateJavascript("window.onNativeAmbientLux && window.onNativeAmbientLux(${latestLux ?: "null"});", null)
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun requestRuntimePermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            permissions.add(Manifest.permission.CAMERA)
        if (permissions.isNotEmpty()) ActivityCompat.requestPermissions(this, permissions.toTypedArray(), 10)
    }

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel("blinkcare_reminders", "BlinkCare reminders", NotificationManager.IMPORTANCE_HIGH)
        channel.description = "Eye-care break reminders"
        manager.createNotificationChannel(channel)
    }

    private fun scheduleUsageCheck() {
        val request = PeriodicWorkRequestBuilder<UsageReminderWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("blinkcare_usage_check", ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    private fun notifyUser(title: String, message: String) {
        val manager = getSystemService(NotificationManager::class.java)
        val intent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, "blinkcare_reminders")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(message)
            .setContentIntent(intent).setAutoCancel(true).build()
        manager.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }

    class NativeBridge(private val activity: Activity) {
        @JavascriptInterface fun getAmbientLux(): String =
            (activity as? MainActivity)?.latestLux?.toString() ?: ""
        @JavascriptInterface fun openUsageAccessSettings() {
            activity.runOnUiThread { activity.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        }
    }
}
