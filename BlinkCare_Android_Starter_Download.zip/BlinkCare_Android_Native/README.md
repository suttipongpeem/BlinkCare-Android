# BlinkCare Android Native – starter project

This is an Android Studio source project that wraps the latest BlinkCare V2.9.1 web experience in a WebView and adds native Android capabilities:
- Android notification channel and runtime notification permission.
- Android Ambient Light Sensor reading when the phone exposes `TYPE_LIGHT`.
- A settings shortcut for Usage Access.
- A WorkManager-based periodic usage check that can issue a break reminder notification.
- The V2.9.1 HTML app is bundled locally in `app/src/main/assets/index.html`.

## Open/build
1. Extract this ZIP.
2. Open the `BlinkCare_Android_Native` folder in Android Studio (current stable).
3. Allow Gradle sync and install the Android SDK platform 35 if prompted.
4. Run on a physical Android phone. Grant Camera and Notifications permissions.
5. Tap **เปิดสิทธิ์ติดตามเวลาการใช้แอป** and enable BlinkCare under Usage Access.
6. Return to BlinkCare and tap **เปิดระบบเตือนพักสายตา**.

## Important implementation limits
- This is an Android Studio source project, not a signed APK. It has not been built or device-tested in this environment.
- WorkManager periodic work has a minimum 15-minute interval and is not an exact 20-minute timer. Android battery optimization and OEM restrictions can delay it.
- UsageStats access is special access and must be enabled by the user. Usage totals and foreground time vary by Android version/vendor; this starter uses a coarse device-wide estimate, not medical-grade screen-time measurement.
- The bundled web page keeps its existing blink detection while BlinkCare is visible. It does NOT silently capture the camera while another app is foregrounded.
- Continuous blink tracking over other apps requires a separately designed, user-started camera foreground service with persistent notification, explicit consent, camera foreground-service declarations, privacy indicator, and Play policy review. Android versions and manufacturers restrict camera access in the background. This is not included or claimed to work here.
- Native light sensor readings are forwarded to the web page through `window.onNativeAmbientLux(lux)` when the page defines that callback. Existing camera brightness remains a separate relative percentage and must not be labelled lux.
- MediaPipe model assets in the original web app are fetched from the network; first launch needs internet access.

## Privacy
Usage Access reveals app-usage metadata. Ask for it only when the user enables cross-app reminders, explain why it is needed, and provide a way to turn the feature off. No usage history is uploaded by this starter.
